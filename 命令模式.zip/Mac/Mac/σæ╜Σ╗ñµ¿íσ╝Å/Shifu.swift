//
//  Shifu.swift
//  Mac
//
//  Created by admin2 on 2020/7/4.
//  Copyright © 2020 admin2. All rights reserved.
//

import Cocoa

class KaoChuanShifu: NSObject {
    func handleKaoChuan() {
        print("进行烤串")
    }
}

class NoodleShifu: NSObject {
    func handleNoodle() {
        print("进行煮面")
    }
}


